package com.tagrus.app
import android.app.Activity
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.view.ViewGroup
import android.widget.*
class MainActivity : Activity() {
 private val tags = mutableListOf<String>()
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); show() }
 private fun show() {
  val root=LinearLayout(this).apply { orientation=1; setPadding(24,32,24,24) }
  root.addView(TextView(this).apply { text="TagRus"; textSize=30f; setPadding(0,0,0,8) })
  root.addView(TextView(this).apply { text="Save and copy hashtags"; textSize=16f })
  val input=EditText(this).apply { hint="Enter hashtag, e.g. smallbusiness"; singleLine=true }
  root.addView(input)
  root.addView(Button(this).apply { text="Save hashtag"; setOnClickListener {
   val t=input.text.toString().trim().removePrefix("#")
   if(t.isNotBlank() && !tags.contains(t)){ tags.add(0,t); show() } else Toast.makeText(this@MainActivity,"Enter a new hashtag",0).show()
  }})
  root.addView(TextView(this).apply { text="Saved hashtags"; textSize=21f; setPadding(0,24,0,8) })
  if(tags.isEmpty()) root.addView(TextView(this).apply { text="No saved hashtags yet." })
  tags.forEach { tag ->
   val row=LinearLayout(this).apply { orientation=0 }
   row.addView(TextView(this).apply { text="#$tag"; textSize=18f },LinearLayout.LayoutParams(0,-2,1f))
   row.addView(Button(this).apply { text="Copy"; setOnClickListener {
    (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("hashtag","#$tag"))
    Toast.makeText(this@MainActivity,"Copied",0).show()
   }})
   root.addView(row)
  }
  root.addView(TextView(this).apply { text="\nInstagram does not provide an approved API for viewing arbitrary recent hashtag posts and commenting on other users' posts. This starter does not collect passwords or automate comments."; textSize=13f })
  setContentView(ScrollView(this).apply { addView(root) })
 }
}
